# Web-based-Automated-Restaurant-Review-checker-app-using-NLP
NLP based automated restaurant review checker App using python and flask
